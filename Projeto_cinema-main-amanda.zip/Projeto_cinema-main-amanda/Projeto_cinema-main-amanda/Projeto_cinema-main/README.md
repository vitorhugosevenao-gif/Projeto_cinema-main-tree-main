Antes de usar!!! Tenha o Visual Studio Code em mãos
Baixe o flask para conseguir visualizar o site utilizando o seguinte código: pip install flask; 
Ou python -m pip install flask

Após instalar o flask, rode o programa no terminal do VSCode com a linha de comando: 
python script.py
*É importante lembrar de estar no mesmo diretório do script para rodar essa linha de comando.

Before using!!! Have Visual Studio Code installed on your computer
Download Flask to view the website
Use the following code: pip install flask; 
Or python -m pip install flask

After installing Flask, run the program in VSCode terminal using the command line:
python script.py
*It's important to remember to be in the same directory as the script to run this command line.
